package com.masai.exception;

public class BookingException extends Exception{
	public BookingException() {
		// TODO Auto-generated constructor stub
	}
	
	public BookingException(String message) {
		super(message);
	}
}
