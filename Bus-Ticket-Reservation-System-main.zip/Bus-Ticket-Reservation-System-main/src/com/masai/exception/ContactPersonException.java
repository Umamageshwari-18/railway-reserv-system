package com.masai.exception;

public class ContactPersonException extends Exception{
	public ContactPersonException() {
		// TODO Auto-generated constructor stub
	}
	
	public ContactPersonException(String message) {
		super(message);
	}
}
