package com.masai.exception;

public class CustomerExeption extends Exception{
	public CustomerExeption() {
		// TODO Auto-generated constructor stub
	}
	
	public CustomerExeption(String message) {
		super(message);
	}
}
