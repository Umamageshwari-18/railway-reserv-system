package com.masai.exception;

public class BusException extends Exception{
	public BusException() {
		// TODO Auto-generated constructor stub
	}
	
	public BusException(String message) {
		super(message);
	}
}
